package com.banor.ipcapture;

import java.io.IOException;
import java.net.MalformedURLException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.json.simple.JSONObject;

public interface IPCaptureHelper {
	int getSystemDetails() throws NullPointerException, IOException, InvalidKeyException, NoSuchAlgorithmException,
			NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, InterruptedException;

	boolean isSystemConnectedToInternet() throws MalformedURLException;

	int checkIsSystemConnectedToInternet() throws NullPointerException, MalformedURLException, InterruptedException;

	void initialExecution() throws IOException, InterruptedException;

	int sendRequireDetails(JSONObject json);
}

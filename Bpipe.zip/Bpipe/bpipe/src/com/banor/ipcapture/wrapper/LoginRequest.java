package com.banor.ipcapture.wrapper;

public class LoginRequest {
	/**
	 * uname entered by the user
	 */
	private String uName;

	public String getuName() {
		return uName;
	}

	public void setuName(String uName) {
		this.uName = uName;
	}

}

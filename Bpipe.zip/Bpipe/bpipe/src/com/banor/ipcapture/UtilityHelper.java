package com.banor.ipcapture;

import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.GraphicsEnvironment;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class UtilityHelper {

	private Properties prop;

	public UtilityHelper() {
		prop = loadPropertyFileData();
	}

	public Properties loadPropertyFileData() {

		final InputStream inputStream = getClass().getClassLoader().getResourceAsStream("config.properties");
		try {
			if (null != inputStream) {
				prop = new Properties();
				prop.load(inputStream);

			} else {
				throw new FileNotFoundException("propFileNotFoundError");
			}
		}

		catch (IOException e) {
			e.printStackTrace();
		}
		return prop;
	}

	public Font getRobotoBold16() throws FontFormatException, IOException {

		Font font;

		font = Font.createFont(Font.TRUETYPE_FONT, getClass().getResource("/Roboto-Bold.ttf").openStream());
		GraphicsEnvironment genv = GraphicsEnvironment.getLocalGraphicsEnvironment();
		genv.registerFont(font);
		font = font.deriveFont(16f);

		return font;
	}

	public Font getRobotoMedium12() throws FontFormatException, IOException {

		Font font;

		font = Font.createFont(Font.TRUETYPE_FONT, getClass().getResource("/Roboto-Medium.ttf").openStream());
		GraphicsEnvironment genv = GraphicsEnvironment.getLocalGraphicsEnvironment();
		genv.registerFont(font);
		font = font.deriveFont(12f);

		return font;
	}

	public Font getRobotoRegular14() throws FontFormatException, IOException {

		Font font;

		font = Font.createFont(Font.TRUETYPE_FONT, getClass().getResource("/Roboto-Regular.ttf").openStream());
		GraphicsEnvironment genv = GraphicsEnvironment.getLocalGraphicsEnvironment();
		genv.registerFont(font);
		font = font.deriveFont(14f);

		return font;
	}

	public Font getRobotoRegular13() throws FontFormatException, IOException {

		Font font;

		font = Font.createFont(Font.TRUETYPE_FONT, getClass().getResource("/Roboto-Regular.ttf").openStream());
		GraphicsEnvironment genv = GraphicsEnvironment.getLocalGraphicsEnvironment();
		genv.registerFont(font);
		font = font.deriveFont(13f);

		return font;
	}

}

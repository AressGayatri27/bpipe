package com.banor.ipcapture.impl;

import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.prefs.Preferences;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.json.simple.JSONObject;

import com.banor.ipcapture.IPCaptureHelper;
import com.banor.ipcapture.PkcsEncDec;
import com.banor.ipcapture.UtilityHelper;
import com.banor.ipcapture.ui.BanorCapitalLogin;
import com.banor.ipcapture.ui.BanorCapitalTrayIcon;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import com.banor.ipcapture.wrapper.LoginRequest;

public class IPCaptureImpl implements IPCaptureHelper {
	// Method for getting Timestamp , Public IP , Private IP , Machine name , Log
	// in,Username
	static UtilityHelper helper = new UtilityHelper();
	static Properties prop = helper.loadPropertyFileData();
	static int sendDataStatusCode;
	static PkcsEncDec pkcEncDec;
	static BanorCapitalLogin frame;
	static JSONObject jsonObject = new JSONObject();

	static Preferences banorPrefs = Preferences.userRoot().node(BanorCapitalLogin.class.getName());
	static String ipCapturefile = prop.getProperty("ipCapturefile");
	static LoginRequest logRequest = new LoginRequest();

	@SuppressWarnings({ "static-access" })
	public int getSystemDetails() throws IOException, InvalidKeyException, NoSuchAlgorithmException,
			NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, InterruptedException {

		String timeStamp = new SimpleDateFormat("yyyy-MM-dd hh.mm.ss aa").format(new Date());
		URL whatismyip = new URL("http://checkip.amazonaws.com/");
		URLConnection connection = whatismyip.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		String publicIP = in.readLine();

		String privateIP = InetAddress.getLocalHost().getHostAddress();

		String systemName = InetAddress.getLocalHost().getHostName();

		String machineusername = System.getProperty("user.name");

		String username = banorPrefs.get(prop.getProperty("banorPrefsUsername"), "");
		
		String version = prop.getProperty("version");

		// Add all required data in JSON Array
		JSONObject jsonInnerObject = new JSONObject();
		jsonInnerObject.put(prop.getProperty("timestamp"), timeStamp);
		jsonInnerObject.put(prop.getProperty("username"), username);
		jsonInnerObject.put(prop.getProperty("machineusername"), machineusername);
		jsonInnerObject.put(prop.getProperty("systemName"), systemName);
		jsonInnerObject.put(prop.getProperty("publicIP"), publicIP);
		jsonInnerObject.put(prop.getProperty("privateIP"), privateIP);
		jsonInnerObject.put(prop.getProperty("banorVersion"), version);
		jsonObject.put(prop.getProperty("data"), jsonInnerObject);

		// Perform data Encryption
		String encryptedText = pkcEncDec.encryptStringWithPublicKey(jsonObject.toJSONString(jsonInnerObject));

		jsonObject.put(prop.getProperty("data"), encryptedText);
		sendDataStatusCode = sendRequireDetails(jsonObject);
		return sendDataStatusCode;

	}

	// Method for check the system connected to Internet or not
	public boolean isSystemConnectedToInternet() throws MalformedURLException {
		boolean isSystemConnectedToInternet = false;

		try {
			URL url = new URL("http://www.google.com");
			URLConnection connection = url.openConnection();
			connection.connect();
			isSystemConnectedToInternet = true;

		} catch (IOException e) {
			isSystemConnectedToInternet = false;
		}

		return isSystemConnectedToInternet;

	}

	// Method for call the method which is checking the system connected to Internet
	// or not
	public int checkIsSystemConnectedToInternet()
			throws NullPointerException, MalformedURLException, InterruptedException {
		boolean isActiveInternet;
		isActiveInternet = isSystemConnectedToInternet();
		if (isActiveInternet) {
			try {
				sendDataStatusCode = getSystemDetails();

				if (sendDataStatusCode == HttpURLConnection.HTTP_UNAUTHORIZED) {
					if (null == frame)
						frame = new BanorCapitalLogin();
					frame.setVisible(true);
				}

			} catch (NullPointerException | InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException
					| IllegalBlockSizeException | BadPaddingException | IOException e) {
				e.addSuppressed(e);
			}
		}
		return sendDataStatusCode;
	}

	// Condition For run Login screen
	public void initialExecution() throws IOException, InterruptedException {
		BanorCapitalTrayIcon trayIcon = new BanorCapitalTrayIcon();
		LoginRequest logReq = new LoginRequest();
		Preferences banPrefs = Preferences.userRoot().node(BanorCapitalLogin.class.getName());
		logReq.setuName(banPrefs.get(prop.getProperty("banorPrefsUsername"), ""));

		if (logReq.getuName().equals("")) {
			if (null == frame)
				frame = new BanorCapitalLogin();
			frame.setVisible(true);
		} else {
			trayIcon.banorCapitalTrayIconInit();

		}

	}

	public int sendRequireDetails(JSONObject json) {
		int dataSendStatusCode = 0;
		HttpURLConnection connection = null;
		try {
			// Create connection
			URL url = new URL(prop.getProperty("saveEncryptedUserData"));
			connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type", "application/json");
			connection.setRequestProperty("Accept", "application/json");
			connection.setDoOutput(true);
			OutputStreamWriter wr = new OutputStreamWriter(connection.getOutputStream());
			wr.write(json.toString());
			wr.flush();
			wr.close();
			int httpResult = connection.getResponseCode();
			dataSendStatusCode = httpResult;

		} catch (Exception e) {
			dataSendStatusCode = HttpURLConnection.HTTP_INTERNAL_ERROR;
		}
		return dataSendStatusCode;
	}

	public static void disposeFrame() {
		frame = null;
	}
}
package com.banor.ipcapture;

import java.util.HashMap;

public interface IPCaptureAPIHelper {

	HashMap<String, String> generateOTPAPIImpl();

	int validateOTPAndUsername() throws NullPointerException;
}

package com.banor.ipcapture.ui;

import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Properties;

import javax.swing.GrayFilter;
import javax.swing.ImageIcon;
import javax.swing.Timer;

import com.banor.ipcapture.UtilityHelper;
import com.banor.ipcapture.impl.IPCaptureImpl;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;

public class BanorCapitalTrayIcon {
	static UtilityHelper helper = new UtilityHelper();
	static Properties prop = helper.loadPropertyFileData();
	static IPCaptureImpl ipCaptureImpl = new IPCaptureImpl();
	private static TrayIcon trayIcon;
	private final PopupMenu popup = new PopupMenu();
	private MenuItem exitItem = new MenuItem("Quit");
	private static String trayIconNotificationTitle = prop.getProperty("trayIconNotificationTitle");
	// Initial execution
	static int interChkTimerInterval = 500;
	// Interval of 30 seconds
	static int interChkTimerDelay = 30000;
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss a");
	LocalDateTime now = LocalDateTime.now();
	String pubIP;
	String priIP;

	// Initialized the system tray icon
	public void banorCapitalTrayIconInit() throws MalformedURLException {
		if (SystemTray.isSupported())
			initSysTray();

		// Call the timer
		timer.setDelay(interChkTimerDelay);
		timer.start();
	}

	// Method for system tray design code
	private void initSysTray() throws MalformedURLException {
		SystemTray tray;
		tray = SystemTray.getSystemTray();

		exitItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				System.exit(0);
			}
		});

		popup.add(exitItem);
		boolean isActiveInternet;
		isActiveInternet = ipCaptureImpl.isSystemConnectedToInternet();
		Image img = new ImageIcon(this.getClass().getResource("/trayicon.png")).getImage();

		if (isActiveInternet) {
			trayIcon = new TrayIcon(img, trayIconNotificationTitle);
		} else {
			trayIcon = new TrayIcon(GrayFilter.createDisabledImage(img), trayIconNotificationTitle);
		}

		try {
			trayIcon.setPopupMenu(popup);
			tray.add(trayIcon);
		} catch (AWTException e) {
			return;
		}
	}

	// Timer for check Internet connectivity continuously
	String ipTimeStampDisconnectInternet = new SimpleDateFormat("yyyy-MM-dd hh.mm.ss aa").format(new Date());
	Timer timer = new Timer(interChkTimerInterval, new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			try {
				int code;
				boolean isActiveInternet;
				code = ipCaptureImpl.checkIsSystemConnectedToInternet();
				isActiveInternet = ipCaptureImpl.isSystemConnectedToInternet();
				String ipTimeStamp = new SimpleDateFormat("yyyy-MM-dd hh.mm.ss ").format(new Date());
				Image img = new ImageIcon(this.getClass().getResource("/trayicon.png")).getImage();
				if (isActiveInternet) {
					URL whatismyip = new URL("http://checkip.amazonaws.com/");
					URLConnection connection = whatismyip.openConnection();
					BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
					pubIP = in.readLine();
					priIP = InetAddress.getLocalHost().getHostAddress();
					trayIcon.setImage(img);
					trayIcon.setToolTip(trayIconNotificationTitle + "\n" + prop.getProperty("iconPublicIP") + pubIP
							+ "\n" + prop.getProperty("iconPrivateIP") + priIP + "\n" + "Last information sent on: "
							+ ipTimeStamp);
				} else {
					trayIcon.setImage(GrayFilter.createDisabledImage(img));
					trayIcon.setToolTip(prop.getProperty("disconnectedInternet"));

				}
				if (isActiveInternet && (code == HttpURLConnection.HTTP_INTERNAL_ERROR)) {
					trayIcon.setImage(GrayFilter.createDisabledImage(img));
					trayIcon.setToolTip(trayIconNotificationTitle + "\n" + prop.getProperty("disconnectedServer"));
				}

			} catch (InterruptedException | NullPointerException | IOException interruptedException) {
				return;
			}

		}
	});

}

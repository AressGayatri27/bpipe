package com.banor.ipcapture.ui;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Insets;
import java.awt.Toolkit;
import javax.swing.JSplitPane;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.Properties;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.SystemColor;

import com.banor.ipcapture.IPCaptureAPIHelper;
import com.banor.ipcapture.UtilityHelper;
import com.banor.ipcapture.impl.IPCaptureImpl;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.file.StandardOpenOption;
import java.util.prefs.Preferences;

import org.json.simple.JSONObject;

public class BanorCapitalLogin extends JFrame implements IPCaptureAPIHelper {

	/**
	 * auto generated serialVersionUID
	 */
	private static final long serialVersionUID = -3924202757620272221L;
	private JTextField unameTextField;
	private JTextField otpTextField1;
	private JTextField otpTextField2;
	private JTextField otpTextField3;
	private JTextField otpTextField4;
	private JTextField otpTextField5;
	private JLabel unameErrorLabel;
	private JLabel unameIncorrectErrorLabel;
	private JLabel unameBlockErrorLabel;
	private JLabel otpErrorLabel;
	private JLabel otpIncorrectErrorLabel;
	private JLabel otpGenerateLabel;
	private JButton loginButton;
	private JLabel otpHyperlink;
	private JLabel disconnectedServer;
	private JLabel intOtpLabel;
	private JLabel otp;
	private JRadioButton txt;
	private JRadioButton email;
	private ButtonGroup otpButtonGroup = new ButtonGroup();	
	private char charInput;
	private boolean otpFields;
	private JSONObject jsonObject = new JSONObject();
	private int otpStatusCode = 0;
	private static Preferences banorPrefs = Preferences.userRoot().node(BanorCapitalLogin.class.getName());
	static UtilityHelper helper = new UtilityHelper();
	private static BanorCapitalTrayIcon banorCapitalTrayIcon;
	private static Properties prop;
	private String contentType = prop.getProperty("contentType");
	private String applicationJson = prop.getProperty("applicationJson");
	private String userName = "userName";
	private String isOtpByEmail = "isOtpByEmail";
	private String otpStatus = "";
	private String blockUname = "Unauthorized access: Try login after";
	private String actualMsg;

	public static void main(String[] args) throws Exception {

		prop = helper.loadPropertyFileData();
		IPCaptureImpl ipCaptureImpl = new IPCaptureImpl();

		// Code for create only the single instance of login screen
		String userHome = System.getProperty("user.home");
		File file = new File(userHome, "my.lock");

		try {
			FileChannel fc = FileChannel.open(file.toPath(), StandardOpenOption.CREATE, StandardOpenOption.WRITE);
			FileLock lock = fc.tryLock();
			if (lock != null) {
				ipCaptureImpl.initialExecution();
			}
		} catch (IOException | InterruptedException e) {
			return;
		}
	}

	public BanorCapitalLogin() {

		try {
			String font = prop.getProperty("font");
			setBackground(Color.WHITE);
			setSize(380, 500);
			setAlwaysOnTop(true);
			setResizable(false);
			setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
			setTitle(prop.getProperty("lblLogin"));
			setIconImage(
					Toolkit.getDefaultToolkit().getImage(getClass().getClassLoader().getResource("banorIcon.png")));
			setBounds(100, 100, 351, 491);
			JPanel contentPane = new JPanel();
			contentPane.setBackground(Color.WHITE);
			contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
			setContentPane(contentPane);
			contentPane.setLayout(null);

			JLabel lblAressIcon = new JLabel("");
			lblAressIcon.setHorizontalAlignment(SwingConstants.CENTER);
			lblAressIcon.setIcon(new ImageIcon(getClass().getClassLoader().getResource("banorcapital.png")));
			lblAressIcon.setBounds(10, 11, 315, 70);
			contentPane.add(lblAressIcon);

			JLabel bpipeLabel = new JLabel("BPIPE - Capture User Info");
			bpipeLabel.setFont(helper.getRobotoBold16());
			bpipeLabel.setForeground(SystemColor.textHighlight);
			bpipeLabel.setHorizontalAlignment(SwingConstants.CENTER);
			bpipeLabel.setBounds(10, 92, 315, 25);
			contentPane.add(bpipeLabel);

			JLabel lblUsername = new JLabel(prop.getProperty("lblUsername"));
			lblUsername.setFont(helper.getRobotoRegular14());
			lblUsername.setBounds(36, 131, 96, 25);
			lblUsername.setForeground(Color.BLACK);
			contentPane.add(lblUsername);

			JLabel lblOtp = new JLabel(prop.getProperty("lblOtp"));
			lblOtp.setFont(helper.getRobotoRegular14());
			lblOtp.setBounds(36, 268, 76, 25);
			lblOtp.setForeground(Color.BLACK);
			contentPane.add(lblOtp);

			// User name split panel
			JSplitPane unameSplitPane = new JSplitPane();
			unameSplitPane.setDividerSize(0);
			unameSplitPane.setBorder(new LineBorder(new Color(211, 211, 211), 0));
			unameSplitPane.setBackground(Color.WHITE);
			unameSplitPane.setForeground(Color.BLACK);
			unameSplitPane.setBounds(36, 167, 255, 32);
			getContentPane().add(unameSplitPane);

			// User name split panel text field part
			unameTextField = new JTextField();
			unameTextfieldEvent();
			unameTextField.setBackground(new Color(240, 248, 255));
			unameTextField.setSelectionColor(Color.WHITE);
			unameTextField.setBorder(new LineBorder(new Color(192, 192, 192)));
			unameTextField.setHorizontalAlignment(SwingConstants.LEFT);
			unameSplitPane.setRightComponent(unameTextField);
			unameTextField.setColumns(10);
			unameTextField.setFont(helper.getRobotoMedium12());
			unameTextField.setBorder(javax.swing.BorderFactory.createCompoundBorder(
					javax.swing.BorderFactory.createTitledBorder(null, null,
							javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
							javax.swing.border.TitledBorder.DEFAULT_POSITION),
					javax.swing.BorderFactory.createEmptyBorder(5, 5, 5, 5)));

			// User name split panel profile image part
			JButton unameButton = new JButton("");
			unameButton.setSize(new Dimension(200, 0));
			unameButton.setPreferredSize(new Dimension(33, 99));
			unameButton.setBorder(new LineBorder(new Color(192, 192, 192)));
			unameButton.setMargin(new Insets(2, 14, 2, 50));
			unameButton.setBackground(new Color(230, 230, 250));
			unameButton.setIcon(new ImageIcon(getClass().getClassLoader().getResource("user.png")));
			unameSplitPane.setLeftComponent(unameButton);

			// First text field for OTP
			otpTextField1 = new JTextField();
			handleOtpTextField1Event();
			otpTextField1.setFont(helper.getRobotoMedium12());
			otpTextField1.setHorizontalAlignment(SwingConstants.CENTER);
			otpTextField1.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
			otpTextField1.setDocument(new JTextFieldLimit(1));
			otpTextField1.setBounds(36, 304, 32, 32);
			getContentPane().add(otpTextField1);
			otpTextField1.setColumns(10);

			// Second text field for OTP
			otpTextField2 = new JTextField();
			handleOtpTextField2Event();
			otpTextField2.setFont(helper.getRobotoMedium12());
			otpTextField2.setHorizontalAlignment(SwingConstants.CENTER);
			otpTextField2.setColumns(10);
			otpTextField2.setDocument(new JTextFieldLimit(1));
			otpTextField2.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
			otpTextField2.setBounds(94, 304, 32, 32);
			getContentPane().add(otpTextField2);

			// Third text field for OTP
			otpTextField3 = new JTextField();
			handleOtpTextField3Event();
			otpTextField3.setFont(helper.getRobotoMedium12());
			otpTextField3.setHorizontalAlignment(SwingConstants.CENTER);
			otpTextField3.setColumns(10);
			otpTextField3.setDocument(new JTextFieldLimit(1));
			otpTextField3.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
			otpTextField3.setBounds(150, 304, 32, 32);
			getContentPane().add(otpTextField3);

			// Fourth text field for OTP
			otpTextField4 = new JTextField();
			handleOtpTextField4Event();
			otpTextField4.setFont(helper.getRobotoMedium12());
			otpTextField4.setHorizontalAlignment(SwingConstants.CENTER);
			otpTextField4.setColumns(10);
			otpTextField4.setDocument(new JTextFieldLimit(1));
			otpTextField4.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
			otpTextField4.setBounds(205, 304, 32, 32);
			getContentPane().add(otpTextField4);

			// Fifth text field for OTP
			otpTextField5 = new JTextField();
			handleOtpTextField5Event();
			otpTextField5.setFont(helper.getRobotoMedium12());
			otpTextField5.setColumns(10);
			otpTextField5.setDocument(new JTextFieldLimit(1));
			otpTextField5.setHorizontalAlignment(SwingConstants.CENTER);
			otpTextField5.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
			otpTextField5.setBounds(259, 304, 32, 32);
			getContentPane().add(otpTextField5);

			loginButton = new JButton(prop.getProperty("lblLogin"));
			loginButton.setFont(new Font(font, Font.BOLD, 12));
			loginButtonEvent();
			loginButton.setFont(helper.getRobotoMedium12());
			loginButton.setBounds(119, 394, 98, 35);
			loginButton.setEnabled(false);
			contentPane.add(loginButton);

			// Error label for blank user name
			unameErrorLabel = new JLabel();
			unameErrorLabel.setVisible(false);
			unameErrorLabel.setForeground(Color.RED);
			unameErrorLabel.setText(prop.getProperty("unameErrorLabel"));
			unameErrorLabel.setBorder(null);
			unameErrorLabel.setBounds(36, 240, 255, 14);
			getContentPane().add(unameErrorLabel);

			// Error label for incorrect user name
			unameIncorrectErrorLabel = new JLabel();
			unameIncorrectErrorLabel.setVisible(false);
			unameIncorrectErrorLabel.setForeground(Color.RED);
			unameIncorrectErrorLabel.setText(prop.getProperty("unameIncorrectErrorLabel"));
			unameIncorrectErrorLabel.setBorder(null);
			unameIncorrectErrorLabel.setBounds(36, 243, 209, 14);
			getContentPane().add(unameIncorrectErrorLabel);

			// Error label for block user name
			unameBlockErrorLabel = new JLabel();
			unameBlockErrorLabel.setVisible(false);
			unameBlockErrorLabel.setForeground(Color.RED);
			unameBlockErrorLabel.setBorder(null);
			unameBlockErrorLabel.setBounds(36, 243, 289, 14);
			getContentPane().add(unameBlockErrorLabel);

			// Error label for blank OTP
			otpErrorLabel = new JLabel();
			otpErrorLabel.setVisible(false);
			otpErrorLabel.setText(prop.getProperty("otpErrorLabel"));
			otpErrorLabel.setForeground(Color.RED);
			otpErrorLabel.setBorder(null);
			otpErrorLabel.setBounds(35, 347, 147, 14);
			getContentPane().add(otpErrorLabel);

			// Error label for incorrect OTP
			otpIncorrectErrorLabel = new JLabel();
			otpIncorrectErrorLabel.setVisible(false);
			otpIncorrectErrorLabel.setText(prop.getProperty("otpIncorrectErrorLabel"));
			otpIncorrectErrorLabel.setForeground(Color.RED);
			otpIncorrectErrorLabel.setBorder(null);
			otpIncorrectErrorLabel.setBounds(36, 361, 242, 14);
			getContentPane().add(otpIncorrectErrorLabel);

			//Radiobutton for email and text 
			otp = new JLabel("OTP :");
			otp.setFont(helper.getRobotoRegular14());
			otp.setBounds(35, 210, 40, 14);
			otp.setForeground(Color.BLACK);
			getContentPane().add(otp);	
			
			txt = new JRadioButton("TXT");
			txt.setFont(helper.getRobotoRegular14());
			txt.setBounds(75, 210, 50, 14);		
			txt.setForeground(Color.BLACK);
			txt.setBackground(Color.WHITE);				
			txt.setSelected(true);	
			
			email = new JRadioButton("EMAIL");
			email.setFont(helper.getRobotoRegular14());
			email.setBounds(125, 210, 70, 14);	
			email.setForeground(Color.BLACK);
			email.setBackground(Color.WHITE);	
			
			ItemListener itemListener = new ItemListener() {
				String lastSelected;
				public void itemStateChanged(ItemEvent itemEvent) {
					AbstractButton aButton = (AbstractButton) itemEvent.getSource();
					int otpState = itemEvent.getStateChange();
					String label = aButton.getText();
					if (otpState == ItemEvent.SELECTED) {
						if (label.equals(lastSelected)) {
							otpStatus = label;
						} else {
							otpStatus = label;
						}
					}
				}
			};
			
			otpButtonGroup.add(txt);
			getContentPane().add(txt);	
			otpButtonGroup.add(email);
			getContentPane().add(email);				
			txt.addItemListener(itemListener);
			email.addItemListener(itemListener);			
						
			// Label for generate OTP text
			otpHyperlink = new JLabel(prop.getProperty("hyperlinkText"));
			otpHyperlink.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			otpHyperlink.setFont(new Font(prop.getProperty("font"), Font.PLAIN, 9));
			otpHyperlink.setForeground(Color.BLUE);
			otpHyperlink.setBounds(85, 230, 207, 14);
			handleOtpHyperlinkEvent(prop.getProperty("hyperlinkText"));
			getContentPane().add(otpHyperlink);

			otpGenerateLabel = new JLabel(prop.getProperty("otpGenerateLabel"));
			otpGenerateLabel.setVisible(false);
			otpGenerateLabel.setForeground(Color.BLUE);
			otpGenerateLabel.setFont(new Font(prop.getProperty("font"), Font.PLAIN, 11));
			otpGenerateLabel.setBounds(38, 240, 253, 14);
			contentPane.add(otpGenerateLabel);

			disconnectedServer = new JLabel(prop.getProperty("disconnServerErrLabel"));
			disconnectedServer.setForeground(Color.RED);
			disconnectedServer.setBounds(38, 228, 253, 14);
			disconnectedServer.setVisible(false);
			contentPane.add(disconnectedServer);

			intOtpLabel = new JLabel(prop.getProperty("enterIntOtpNumber"));
			intOtpLabel.setForeground(Color.RED);
			intOtpLabel.setBounds(36, 347, 201, 14);
			intOtpLabel.setVisible(false);
			contentPane.add(intOtpLabel);

		} catch (FontFormatException | IOException e) {
			return;
		}

	}
	public boolean isOtpByEmail() {
		boolean otpByEmail = false;
		if(otpStatus.equals("TXT"))
		{
			return otpByEmail;
		}
		else if (otpStatus.equals("EMAIL"))
		{
			otpByEmail = true;
		}
		return otpByEmail;
	}
	
	private void unameTextfieldEvent() {
		unameTextField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				int keyCode = e.getKeyCode();
				if (keyCode == 10) {
					otpTextField1.requestFocus();
				}
				if (Character.isAlphabetic(keyCode)) {
					unameErrorLabel.setVisible(false);
					unameIncorrectErrorLabel.setVisible(false);
				}

				if (keyCode == KeyEvent.VK_DOWN) {
					otpTextField1.requestFocus();
				}
			}

		});
	}
 
	private void handleOtpHyperlinkEvent(String text) {
		otpHyperlink.addMouseListener(new MouseListener() {

			@Override
			public void mouseClicked(java.awt.event.MouseEvent e) {				

				HashMap<String, String> result = generateOTPAPIImpl();

				otpStatusCode = Integer.parseInt(result.get("responseCode"));
				if (unameTextField.getText().equalsIgnoreCase("")) {
					unameErrorLabel.setVisible(true);
					unameIncorrectErrorLabel.setVisible(false);
					unameBlockErrorLabel.setVisible(false);
				} else if (otpStatusCode == HttpURLConnection.HTTP_OK) {
					otpHyperlink.setVisible(false);
					otpGenerateLabel.setVisible(true);
					unameErrorLabel.setVisible(false);
					unameIncorrectErrorLabel.setVisible(false);
					loginButton.setEnabled(true);
					unameBlockErrorLabel.setVisible(false);
				} else if (otpStatusCode == HttpURLConnection.HTTP_UNAUTHORIZED) {
					unameIncorrectErrorLabel.setVisible(true);
					unameBlockErrorLabel.setVisible(false);
					unameErrorLabel.setVisible(false);
					clearAllTextfields();
				} else if (otpStatusCode == HttpURLConnection.HTTP_FORBIDDEN) {
					unameBlockErrorLabel.setText(result.get("errorMessage"));
					unameBlockErrorLabel.setVisible(true);
					unameErrorLabel.setVisible(false);
					unameIncorrectErrorLabel.setVisible(false);
					otpIncorrectErrorLabel.setVisible(false);
					clearAllTextfields();
				} else {
					unameIncorrectErrorLabel.setVisible(false);
				}

				if (otpStatusCode == HttpURLConnection.HTTP_INTERNAL_ERROR) {
					disconnectedServer.setVisible(true);
					unameErrorLabel.setVisible(false);
				} else {
					disconnectedServer.setVisible(false);
				}

			}

			@Override
			public void mousePressed(java.awt.event.MouseEvent e) throws UnsupportedOperationException {
				// Not need to define this method
			}

			@Override
			public void mouseReleased(java.awt.event.MouseEvent e) throws UnsupportedOperationException {
				// Not need to define this method
			}

			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				otpHyperlink.setText("<html><a href=''>" + text + "</a></html>");

			}

			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				otpHyperlink.setText(text);

			}

		});
	}

	private void loginButtonEvent() {
		loginButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					unameIncorrectErrorLabel.setVisible(false);
					validate();
				} catch (Exception nullPointerException) {
					return;
				}
			}

			private void validate() throws NullPointerException, MalformedURLException {
				boolean valid = blankTextFieldsValidation();
				if (valid) {
					int validationStatusCode = validateOTPAndUsername();
					otpTextField1.getText();
					otpTextField2.getText();
					otpTextField3.getText();
					otpTextField4.getText();
					otpTextField5.getText();

					if (unameTextField.getText().equalsIgnoreCase("")) {
						unameErrorLabel.setVisible(true);
						unameIncorrectErrorLabel.setVisible(false);
						unameBlockErrorLabel.setVisible(false);
					} else {
						unameIncorrectErrorLabel.setVisible(false);
					}

					otpTextfieldValidation(validationStatusCode);

					if (validationStatusCode == HttpURLConnection.HTTP_OK) {
						banorPrefs.put("Username", unameTextField.getText());
						dispose();
						IPCaptureImpl.disposeFrame();
						banorCapitalTrayIcon = new BanorCapitalTrayIcon();
						banorCapitalTrayIcon.banorCapitalTrayIconInit();
					} else if (validationStatusCode == HttpURLConnection.HTTP_UNAUTHORIZED) {
						clearOtpTextfields();
					}

				}
			}

			private void clearOtpTextfields() {
				otpTextField1.setText("");
				otpTextField2.setText("");
				otpTextField3.setText("");
				otpTextField4.setText("");
				otpTextField5.setText("");
			}
		});
	}

	private void otpTextfieldValidation(int validationStatusCode) {
		otpFields = otpTextField1.getText().equalsIgnoreCase("") || otpTextField2.getText().equalsIgnoreCase("")
				|| otpTextField3.getText().equalsIgnoreCase("") || otpTextField4.getText().equalsIgnoreCase("")
				|| otpTextField5.getText().equalsIgnoreCase("");
		if (otpFields) {
			otpErrorLabel.setVisible(true);
			otpIncorrectErrorLabel.setVisible(false);
			intOtpLabel.setVisible(false);
		} else if (validationStatusCode == HttpURLConnection.HTTP_UNAUTHORIZED) {
			otpIncorrectErrorLabel.setVisible(true);
			otpErrorLabel.setVisible(false);
			intOtpLabel.setVisible(false);
		} else if (validationStatusCode == HttpURLConnection.HTTP_OK) {
			otpIncorrectErrorLabel.setVisible(false);
			otpErrorLabel.setVisible(false);
		} else {
			otpErrorLabel.setVisible(false);
		}

	}

	boolean blankTextFieldsValidation() {

		boolean allTextFields = unameTextField.getText().equalsIgnoreCase("")
				|| otpTextField1.getText().equalsIgnoreCase("") || otpTextField2.getText().equalsIgnoreCase("")
				|| otpTextField3.getText().equalsIgnoreCase("") || otpTextField4.getText().equalsIgnoreCase("")
				|| otpTextField5.getText().equalsIgnoreCase("");

		otpFields = otpTextField1.getText().equalsIgnoreCase("") || otpTextField2.getText().equalsIgnoreCase("")
				|| otpTextField3.getText().equalsIgnoreCase("") || otpTextField4.getText().equalsIgnoreCase("")
				|| otpTextField5.getText().equalsIgnoreCase("");

		if (allTextFields) {
			unameErrorLabel.setVisible(true);
			otpErrorLabel.setVisible(true);
			otpIncorrectErrorLabel.setVisible(false);
			intOtpLabel.setVisible(false);
			rootPaneCheckingEnabled = false;
			unameBlockErrorLabel.setVisible(false);
		} else {
			unameErrorLabel.setVisible(false);
			otpErrorLabel.setVisible(false);
			rootPaneCheckingEnabled = true;
		}
		if (!unameTextField.getText().equalsIgnoreCase("")) {
			unameErrorLabel.setVisible(false);
			otpErrorLabel.setVisible(true);
			otpIncorrectErrorLabel.setVisible(false);
		}
		if (!otpFields && unameTextField.getText().equalsIgnoreCase("")) {
			unameErrorLabel.setVisible(true);
			otpErrorLabel.setVisible(false);
			unameBlockErrorLabel.setVisible(false);
			unameIncorrectErrorLabel.setVisible(false);
		}

		return rootPaneCheckingEnabled;

	}

	private void handleOtpTextField5Event() {
		otpTextField5.addKeyListener(new KeyAdapter() {

			@Override
			public void keyPressed(KeyEvent e) {

				charInput = e.getKeyChar();

				if (!(Character.isDigit(charInput))) {
					intOtpLabel.setVisible(true);
					otpErrorLabel.setVisible(false);
					otpTextField5.requestFocus();
					otpIncorrectErrorLabel.setVisible(false);
				} else {
					otpTextField5.setText(String.valueOf(charInput));
					otpTextField5.requestFocus();
					intOtpLabel.setVisible(false);
					otpErrorLabel.setVisible(false);
					otpIncorrectErrorLabel.setVisible(false);
				}

				int keyCode = e.getKeyCode();

				switch (keyCode) {
				case KeyEvent.VK_UP:
					intOtpLabel.setVisible(false);
					break;
				case KeyEvent.VK_LEFT:
					handleOtpTextField5LeftBackKeyEvent();
					break;
				case KeyEvent.VK_RIGHT:
					otpTextField5.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
					intOtpLabel.setVisible(false);
					break;
				case KeyEvent.VK_BACK_SPACE:
					handleOtpTextField5LeftBackKeyEvent();
					break;
				case KeyEvent.VK_DOWN:
					intOtpLabel.setVisible(false);
					break;
				case KeyEvent.VK_ENTER:
					intOtpLabel.setVisible(false);
					otpTextField5.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
					loginButton.requestFocus();
					break;
				default:
					otpTextField5.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
				}
			}

			private void handleOtpTextField5LeftBackKeyEvent() {
				otpTextField5.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
				otpTextField4.requestFocus();
				otpTextField4.setBorder(new LineBorder(new Color(0, 204, 255), 2));
				intOtpLabel.setVisible(false);
			}
		});
	}

	private void handleOtpTextField4Event() {
		otpTextField4.addKeyListener(new KeyAdapter() {

			@Override
			public void keyPressed(KeyEvent e) {

				charInput = e.getKeyChar();

				if (!(Character.isDigit(charInput))) {
					intOtpLabel.setVisible(true);
					otpErrorLabel.setVisible(false);
					otpTextField4.requestFocus();
					otpIncorrectErrorLabel.setVisible(false);
				} else {
					otpTextField4.setText(String.valueOf(charInput));
					otpTextField5.requestFocus();
					intOtpLabel.setVisible(false);
					otpErrorLabel.setVisible(false);
					otpIncorrectErrorLabel.setVisible(false);
				}

				otpTextField4.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
				int keyCode = e.getKeyCode();

				switch (keyCode) {

				case KeyEvent.VK_UP:
					intOtpLabel.setVisible(false);
					break;
				case KeyEvent.VK_LEFT:
					handleOtpTextField4LeftBackKeyEvent();
					break;
				case KeyEvent.VK_RIGHT:
					otpTextField4.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
					otpTextField5.requestFocus();
					otpTextField5.setBorder(new LineBorder(new Color(0, 204, 255), 2));
					intOtpLabel.setVisible(false);
					break;
				case KeyEvent.VK_BACK_SPACE:
					handleOtpTextField4LeftBackKeyEvent();
					break;
				case KeyEvent.VK_DOWN:
					intOtpLabel.setVisible(false);
					break;
				case KeyEvent.VK_ENTER:
					intOtpLabel.setVisible(false);
					break;

				default:
					otpTextField4.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
				}
			}

			private void handleOtpTextField4LeftBackKeyEvent() {
				otpTextField4.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
				otpTextField3.requestFocus();
				otpTextField3.setBorder(new LineBorder(new Color(0, 204, 255), 2));
				intOtpLabel.setVisible(false);
			}

		});
	}

	private void handleOtpTextField3Event() {
		otpTextField3.addKeyListener(new KeyAdapter() {

			@Override
			public void keyPressed(KeyEvent e) {
				otpTextField3.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
				charInput = e.getKeyChar();

				if (!(Character.isDigit(charInput))) {
					intOtpLabel.setVisible(true);
					otpErrorLabel.setVisible(false);
					otpTextField3.requestFocus();
					otpIncorrectErrorLabel.setVisible(false);
				} else {
					otpTextField3.setText(String.valueOf(charInput));
					otpTextField4.requestFocus();
					intOtpLabel.setVisible(false);
					otpErrorLabel.setVisible(false);
					otpIncorrectErrorLabel.setVisible(false);
				}

				int keyCode = e.getKeyCode();

				switch (keyCode) {

				case KeyEvent.VK_UP:
					intOtpLabel.setVisible(false);
					break;
				case KeyEvent.VK_LEFT:
					handleOtpTextField3LeftBackKeyEvent();
					break;
				case KeyEvent.VK_RIGHT:
					otpTextField3.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
					otpTextField4.requestFocus();
					otpTextField4.setBorder(new LineBorder(new Color(0, 204, 255), 2));
					intOtpLabel.setVisible(false);
					break;
				case KeyEvent.VK_BACK_SPACE:
					handleOtpTextField3LeftBackKeyEvent();
					break;
				case KeyEvent.VK_DOWN:
					intOtpLabel.setVisible(false);
					break;
				case KeyEvent.VK_ENTER:
					intOtpLabel.setVisible(false);
					break;

				default:
					otpTextField3.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
				}
			}

			private void handleOtpTextField3LeftBackKeyEvent() {
				otpTextField3.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
				otpTextField2.requestFocus();
				otpTextField2.setBorder(new LineBorder(new Color(0, 204, 255), 2));
				intOtpLabel.setVisible(false);
			}

		});
	}

	private void handleOtpTextField2Event() {
		otpTextField2.addKeyListener(new KeyAdapter() {

			@Override
			public void keyPressed(KeyEvent e) {

				charInput = e.getKeyChar();

				if (!(Character.isDigit(charInput))) {
					intOtpLabel.setVisible(true);
					otpErrorLabel.setVisible(false);
					otpTextField2.requestFocus();
					otpIncorrectErrorLabel.setVisible(false);
				} else {
					otpTextField2.setText(String.valueOf(charInput));
					otpTextField3.requestFocus();
					intOtpLabel.setVisible(false);
					otpErrorLabel.setVisible(false);
					otpIncorrectErrorLabel.setVisible(false);
				}

				otpTextField2.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
				int keyCode = e.getKeyCode();

				switch (keyCode) {

				case KeyEvent.VK_UP:
					intOtpLabel.setVisible(false);
					break;
				case KeyEvent.VK_LEFT:
					handleOtpTextField2LeftBackKeyEvent();
					break;
				case KeyEvent.VK_RIGHT:
					otpTextField2.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
					otpTextField3.requestFocus();
					otpTextField3.setBorder(new LineBorder(new Color(0, 204, 255), 2));
					intOtpLabel.setVisible(false);
					break;
				case KeyEvent.VK_BACK_SPACE:
					handleOtpTextField2LeftBackKeyEvent();
					break;
				case KeyEvent.VK_DOWN:
					intOtpLabel.setVisible(false);
					break;
				case KeyEvent.VK_ENTER:
					intOtpLabel.setVisible(false);
					break;

				default:
					otpTextField2.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
				}
			}

			private void handleOtpTextField2LeftBackKeyEvent() {
				otpTextField2.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
				otpTextField1.requestFocus();
				otpTextField1.setBorder(new LineBorder(new Color(0, 204, 255), 2));
				intOtpLabel.setVisible(false);
			}
		});
	}

	private void handleOtpTextField1Event() {
		otpTextField1.addMouseMotionListener(new MouseMotionAdapter() {

			@Override
			public void mouseMoved(MouseEvent e) {
				otpTextField1.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
			}
		});

		otpTextField1.addKeyListener(new KeyAdapter() {

			@Override
			public void keyPressed(KeyEvent e) {

				charInput = e.getKeyChar();

				if (!(Character.isDigit(charInput))) {
					intOtpLabel.setVisible(true);
					otpErrorLabel.setVisible(false);
					otpTextField1.requestFocus();
					otpIncorrectErrorLabel.setVisible(false);
				} else {
					otpTextField1.setText(String.valueOf(charInput));
					otpTextField2.requestFocus();
					otpErrorLabel.setVisible(false);
					intOtpLabel.setVisible(false);
					otpIncorrectErrorLabel.setVisible(false);
				}

				otpGenerateLabel.setVisible(false);
				otpHyperlink.setVisible(true);
				int keyCode = e.getKeyCode();

				switch (keyCode) {
				case KeyEvent.VK_UP:
					unameTextField.requestFocus();
					intOtpLabel.setVisible(false);
					break;
				case KeyEvent.VK_RIGHT:
					otpTextField1.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
					otpTextField2.requestFocus();
					otpTextField2.setBorder(new LineBorder(new Color(0, 204, 255), 2));
					intOtpLabel.setVisible(false);
					break;
				case KeyEvent.VK_LEFT:
					unameTextField.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
					intOtpLabel.setVisible(false);
					break;
				case KeyEvent.VK_BACK_SPACE:
					unameTextField.requestFocus();
					otpTextField2.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
					otpTextField1.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
					intOtpLabel.setVisible(false);
					break;
				case KeyEvent.VK_DOWN:
					intOtpLabel.setVisible(false);
					break;
				case KeyEvent.VK_ENTER:
					intOtpLabel.setVisible(false);
					break;
				default:
					otpTextField1.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
				}
			}
		});

	}

	private void clearAllTextfields() {
		unameTextField.setText("");
		otpTextField1.setText("");
		otpTextField2.setText("");
		otpTextField3.setText("");
		otpTextField4.setText("");
		otpTextField5.setText("");

	}

	public HashMap<String, String> generateOTPAPIImpl() {
		String cmpErrorMsg;
		HashMap<String, String> result = new HashMap<>();

		boolean otpByEmail = isOtpByEmail();
		String uname = unameTextField.getText();
		if (!uname.equals("")) {
			jsonObject.put(userName, uname);
			jsonObject.put(isOtpByEmail, otpByEmail);
			HttpURLConnection connection = null;

			try {
				// Create connection
				URL url = new URL(prop.getProperty("generateBpipeOtp"));
				connection = (HttpURLConnection) url.openConnection();
				connection.setRequestMethod("POST");
				connection.setRequestProperty(contentType, applicationJson);
				connection.setDoOutput(true);

				OutputStreamWriter wr = new OutputStreamWriter(connection.getOutputStream());
				wr.write(jsonObject.toString());
				wr.flush();
				wr.close();
				otpStatusCode = connection.getResponseCode();

				if (otpStatusCode == HttpURLConnection.HTTP_UNAUTHORIZED) {
					try (BufferedReader bufferedReader = new BufferedReader(
							new InputStreamReader(connection.getErrorStream()))) {
						String line;
						while ((line = bufferedReader.readLine()) != null) {
							actualMsg = line;
						}
					}
					cmpErrorMsg = actualMsg.substring(0, 36);
					if (cmpErrorMsg.equalsIgnoreCase(blockUname)) {
						otpStatusCode = HttpURLConnection.HTTP_FORBIDDEN;
					} else {
						otpStatusCode = HttpURLConnection.HTTP_UNAUTHORIZED;
					}
				}

			} catch (IOException e) {
				otpStatusCode = HttpURLConnection.HTTP_INTERNAL_ERROR;
				unameBlockErrorLabel.setVisible(false);
			}
		}

		result.put("responseCode", String.valueOf(otpStatusCode));
		result.put("errorMessage", actualMsg);
		return result;
	}

	public int validateOTPAndUsername() throws NullPointerException {

		HttpURLConnection connection = null;
		String uname = unameTextField.getText();
		String otp = otpTextField1.getText() + otpTextField2.getText() + otpTextField3.getText()
				+ otpTextField4.getText() + otpTextField5.getText();
		int validationStatusCode = 0;
		jsonObject.put("otp", otp);
		jsonObject.put(userName, uname);

		try {
			// Create connection
			URL url = new URL(prop.getProperty("verifyBpipeOtp"));
			connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("POST");
			connection.setRequestProperty(contentType, applicationJson);
			connection.setDoOutput(true);

			OutputStreamWriter wr = new OutputStreamWriter(connection.getOutputStream());
			wr.write(jsonObject.toString());
			wr.flush();
			wr.close();
			int httpResult = connection.getResponseCode();
			validationStatusCode = httpResult;
		} catch (IOException e) {
			validationStatusCode = HttpURLConnection.HTTP_INTERNAL_ERROR;
			unameBlockErrorLabel.setVisible(false);
		}
		return validationStatusCode;
	}
}

//Class for applying the text limit to OTP all text fields
class JTextFieldLimit extends PlainDocument {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int limit;

	JTextFieldLimit(int limit) {
		super();
		this.limit = limit;
	}

	@Override
	public void insertString(int offset, String str, AttributeSet attr) throws BadLocationException {
		if (str == null)
			return;
		if ((getLength() + str.length()) <= limit) {
			super.insertString(offset, str, attr);
		}
	}
}

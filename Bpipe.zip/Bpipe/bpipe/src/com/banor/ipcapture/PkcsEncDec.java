package com.banor.ipcapture;

import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class PkcsEncDec {
	static String publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAguqkrqtuV254i71x4pNYB0pWOCpmw4TY2G4+fH0hAo8xEBP5Gu/NbZ7HpnsOH1HcnNkct7SEVpwNyVdg/oi78beXQwgF72mdNlD+SvRhjrAenRa0xnCGWbSH+x0/rTzf0ErC69qTfyKeiA25tVmxHPRCzColnZdAoyJnAu45RPsTv8ZQHe91CZ9yl1uUEH+t8uY/yq0YIIlq++IWSohq1p26oNoOKu7U4hmoJFzgC4dYRztS8MLhlVRGkwEC3YaupJMGde9TdTRwD0JJCQ7k5LJAqmgCrwYuxAJAFNgnvOWIZC4woz1rfAyozujnPZx+34r+sZ7FKIcpsIfWRQAHEQIDAQAB";

	private PkcsEncDec() {
		super();
	}

	public static String encryptStringWithPublicKey(String s) {
		String enc = null;
		Cipher cipher = null;
		try {
			cipher = Cipher.getInstance("RSA");
			byte[] keyBytes = Base64.getDecoder().decode(publicKey);
			X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
			KeyFactory kf = KeyFactory.getInstance("RSA");
			PublicKey pubkey = kf.generatePublic(spec);
			cipher.init(Cipher.ENCRYPT_MODE, pubkey);
			enc = Base64.getEncoder().encodeToString(cipher.doFinal(s.getBytes(StandardCharsets.UTF_8)));
		} catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeySpecException | InvalidKeyException
				| IllegalBlockSizeException | BadPaddingException e) {
			e.addSuppressed(e);
		}

		return enc;
	}

}
